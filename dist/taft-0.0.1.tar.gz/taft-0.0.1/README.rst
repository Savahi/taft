TAFT: Technical Analysis tools For Trading 
