from setuptools import setup

setup( 
	name='taft',
	version='0.0.1',
	description='Technical Analysis For Trading',
	url='http://github.com/Savahi/taft',
	author='Savahi',
	author_email='sh@tradingene.ru',
	license='MIT',
	packages=['taft'],
	zip_safe=False )
